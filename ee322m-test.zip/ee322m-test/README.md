1. Collected data for different activities are in sitting_new.csv, stairs.csv, walking.csv for the respective activities.
2. Features extracted using matlab code is in file feature_extract.m using supporting matlab file.
3. file11.csv, file22.csv file33.csv contains extracted features data for sitting, stairs descending/ascending, walking respectively.
4. file44.csv, file55.csv, file 66.csv have the testing data.
5. acc_python.ipynb is python file for classifying data and the accuracy achieved
